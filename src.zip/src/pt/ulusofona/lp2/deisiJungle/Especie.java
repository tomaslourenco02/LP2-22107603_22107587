package pt.ulusofona.lp2.deisiJungle;

import javax.swing.*;

public class Especie {

    String identificador;
    String nome;
    String imagem;

    public Especie(String identificador, String nome, String imagem) {

        this.identificador = identificador;
        this.nome = nome;
        this.imagem = imagem;
    }
}
